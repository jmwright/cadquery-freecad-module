# -*- coding: utf-8 -*-
"""
pyQode is a source code editor widget for Python Qt (PyQt5/PyQt4/PySide)

pyQode is a **namespace package**.
"""
import pkg_resources
pkg_resources.declare_namespace(__name__)
