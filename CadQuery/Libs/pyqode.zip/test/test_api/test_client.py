# -*- coding: utf-8 -*-
"""
Test the client/server API
"""
