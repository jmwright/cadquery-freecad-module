Main Authors
============

Colin Duquesnoy (@ColinDuquesnoy) <colin.duquesnoy@gmail.com>

Code Contributors
=================

Andres Granada (@ogranada)