pyqode.core.managers package
============================

.. toctree::
   :maxdepth: 4

Module content
--------------

.. automodule:: pyqode.core.managers


Classes
-------

BackendManager
++++++++++++++

.. autoclass:: pyqode.core.managers.BackendManager
    :members:
    :undoc-members:
    :show-inheritance:

FileManager
+++++++++++

.. autoclass:: pyqode.core.managers.FileManager
    :members:
    :undoc-members:
    :show-inheritance:

ModesManager
++++++++++++

.. autoclass:: pyqode.core.managers.ModesManager
    :members:
    :undoc-members:
    :show-inheritance:

PanelsManager
+++++++++++++

.. autoclass:: pyqode.core.managers.PanelsManager
    :members:
    :undoc-members:
    :show-inheritance:

TextDecorationsManager
++++++++++++++++++++++

.. autoclass:: pyqode.core.managers.TextDecorationsManager
    :members:
    :undoc-members:
    :show-inheritance:

