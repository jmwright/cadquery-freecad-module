pyqode.core.styles package
==========================

Module contents
---------------

.. automodule:: pyqode.core.styles
    :members:
    :show-inheritance:
