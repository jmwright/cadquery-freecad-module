It is ok for files in this directory to import FreeCAD, FreeCAD.Base, and FreeCAD.Part.

Other modules should _not_ depend on FreeCAD