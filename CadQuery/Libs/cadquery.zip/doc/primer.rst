.. _3d_cad_primer:

***********************
3D CAD Primer
***********************

This section provides a basic introduction to 3D modeling. It will get you started with the basics. After that,
you may want to do some heavier reading on the subject (PUT LINKS HERE )

