Changes
=======


v0.1
-----
    * Initial Version

v0.1.6
-----
    * Added STEP import and supporting tests

v0.1.7
-----
    * Added revolve operation and supporting tests
    * Fixed minor documentation errors