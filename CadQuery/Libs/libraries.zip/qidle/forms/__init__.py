"""
This package contains the qt designer ui script.

To update the content of this package, run setup.py build_ui (you need
pyqt-distutils and pyqode-uic packages from pypi).

"""
